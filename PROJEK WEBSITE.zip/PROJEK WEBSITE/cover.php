<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Lost & Found Sekolah</title>

<style>

body{
  margin:0;
  font-family:'Segoe UI', sans-serif;
}

/* COVER */
.cover{
  width:100%;
  height:100vh;

  background:
  linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
  url("http://localhost/PROJEK%20WEBSITE/bg.jpg");

  background-size:cover;
  background-position:center;
  background-repeat:no-repeat;

  display:flex;
  align-items:center;

  animation:bgZoom 8s ease infinite alternate;
}

/* OVERLAY */
.overlay{
  width:100%;
  height:100%;
  display:flex;
  align-items:center;
}

/* CONTENT */
.content{
  color:white;
  padding:30px;
  max-width:400px;

  animation:fadeUp 1s ease;
}

.content h1{
  font-size:60px;
  line-height:1.1;
  margin-bottom:20px;
}

.content p{
  font-size:20px;
  line-height:1.5;
  margin-bottom:35px;
  color:#f1f1f1;
}

/* BUTTON */
.cover-btn{
  background:#093C5D;
  color:white;
  padding:16px 35px;
  border-radius:40px;
  text-decoration:none;
  display:inline-block;
  font-size:18px;
  font-weight:bold;

  transition:0.2s;
  animation:fadeUp 1.4s ease;
}

.cover-btn:hover{
  transform:scale(1.05);
  background:#3b82f6;
}

/* ANIMASI TEXT */
@keyframes fadeUp{
  from{
    opacity:0;
    transform:translateY(40px);
  }

  to{
    opacity:1;
    transform:translateY(0);
  }
}

/* ANIMASI BG */
@keyframes bgZoom{
  from{
    background-size:100%;
  }

  to{
    background-size:110%;
  }
}

</style>

</head>
<body>

<div class="cover">

  <div class="overlay">

    <div class="content">

      <h1>
        Temukan Barangmu<br>
        di Sekolah
      </h1>

      <p>
        Platform laporan kehilangan barang
        untuk siswa dan guru di sekolah
      </p>

      <a href="login.php" class="cover-btn">
        Masuk Sekarang
      </a>

    </div>

  </div>

</div>

</body>
</html>