<?php
session_start();
include 'config.php';

$nama = $_GET['nama'];
$email = $_GET['email'];

$cek = $koneksi->query("SELECT * FROM users WHERE username='$email'");

if($cek->num_rows == 0){
  $koneksi->query("INSERT INTO users(username,password) VALUES('$email','google')");
}

$_SESSION['user'] = $email;

header("Location: index.php");
?>