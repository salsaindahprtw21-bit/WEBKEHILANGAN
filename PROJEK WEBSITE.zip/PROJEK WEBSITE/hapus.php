<?php include 'config.php'; ?>

<?php
$id = $_GET['id'];
$koneksi->query("DELETE FROM laporan WHERE id=$id");
header("Location: index.php");
?>