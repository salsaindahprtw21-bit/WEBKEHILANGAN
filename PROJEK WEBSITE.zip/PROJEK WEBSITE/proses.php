<?php
include 'config.php';

$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$kategori = $_POST['kategori'];
$barang = $_POST['barang'];
$deskripsi = $_POST['deskripsi'];

/* cek upload foto */
$foto = "";

if($_FILES['foto']['name'] != ""){

  $foto = $_FILES['foto']['name'];
  $tmp = $_FILES['foto']['tmp_name'];

  move_uploaded_file($tmp, "upload/".$foto);
}

/* simpan */
mysqli_query($koneksi,
"INSERT INTO laporan(nama,kelas,kategori,barang,deskripsi,foto)
VALUES('$nama','$kelas','$kategori','$barang','$deskripsi','$foto')");

header("Location:index.php");
?>