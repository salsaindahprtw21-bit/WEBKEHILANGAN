<?php include 'config.php'; ?>

<?php
if(isset($_POST['login'])){
  $user = $_POST['username'];
  $pass = $_POST['password'];

  $data = $koneksi->query("SELECT * FROM users WHERE username='$user'");
  $d = $data->fetch_assoc();

  if($d && password_verify($pass, $d['password'])){
    $_SESSION['user'] = $d['username'];
    header("Location: index.php");
  } else {
    echo "Login gagal";
  }
}
?>

<link rel="stylesheet" href="style.css">

<form method="post" class="card">
<h2>Login Siswa</h2>
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button name="login" class="btn">Masuk</button>

<script src="https://accounts.google.com/gsi/client" async defer></script>

<div id="g_id_onload"
 data-client_id="638231628160-7n8qd69k8cd0a6rbchmqcm72uf290oqo.apps.googleusercontent.com"
 data-callback="handleCredentialResponse">
</div>

<div class="g_id_signin"></div>

<script>
function handleCredentialResponse(response) {
  const data = parseJwt(response.credential);
  const nama = data.name;
  const email = data.email;

  window.location.href = "google_login.php?nama=" + nama + "&email=" + email;
}

function parseJwt (token) {
  var base64Url = token.split('.')[1];
  var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));

  return JSON.parse(jsonPayload);
}
</script>

<a href="register.php">Belum punya akun? Daftar</a>
</form>