<?php include 'config.php'; ?>
<?php if(!isset($_SESSION['user'])) header("Location: login.php"); ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Laporan Kehilangan Sekolah</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="header">
  
  <div class="header-left">
    <img src="upload/user.png">
    <span class="username">
      <?php echo $_SESSION['user']; ?>
    </span>
  </div>

  <a href="logout.php" class="logout">Logout</a>

</div>

<div class="app">
<h2 class="title">Laporan Kehilangan di Sekolah</h2>
<p class="subtitle">Halo, <?php echo $_SESSION['user']; ?> 👋</p>
<h3 style="margin-top:10px;">Buat Laporan</h3>

<form action="proses.php" method="post" enctype="multipart/form-data" class="card">
<input type="text" name="nama" placeholder="Nama Siswa" required>
<input type="text" name="kelas" placeholder="Kelas" required>

<select name="kategori" required>
  <option value="">Pilih Jenis Barang</option>
  <option>Tas</option>
  <option>Buku</option>
  <option>HP</option>
  <option>Dompet</option>
  <option>Lainnya</option>
</select>

<input type="text" name="barang" placeholder="Nama Barang" required>
<textarea name="deskripsi" placeholder="Ciri-ciri / lokasi terakhir"></textarea>
<input type="file" name="foto">

<button type="submit" class="btn">Kirim Laporan</button>
</form>

<h3 id="laporan">Daftar Laporan</h3>

<?php
$data = $koneksi->query("SELECT * FROM laporan ORDER BY id DESC");
while($d = $data->fetch_assoc()){
?>
<div id="profil" class="card">
  <h3>Profil</h3>
  <p>Username: <?php echo $_SESSION['user']; ?></p>
</div>

<div class="card laporan">
<?php if($d['foto'] != ""){ ?>
  <img src="upload/<?php echo $d['foto']; ?>" class="img">
<?php } ?>

<div class="isi">
<b><?php echo $d['barang']; ?></b>
<p><?php echo $d['nama']; ?> - <?php echo $d['kelas']; ?></p>
<small><?php echo $d['deskripsi']; ?></small>

<div class="badge"><?php echo $d['kategori']; ?></div>

<div class="aksi">
<a href="edit.php?id=<?php echo $d['id']; ?>" class="edit">Edit</a>
<a href="hapus.php?id=<?php echo $d['id']; ?>" class="hapus" onclick="return confirm('Yakin?')">Hapus</a>
</div>

</div>
</div>

<?php } ?>

<div class="navbar">
  <a href="#" class="nav-item active">🏠<br><span>Home</span></a>
  <a href="#laporan" class="nav-item">📄<br><span>Laporan</span></a>
  <a href="#profil" class="nav-item">👤<br><span>Profil</span></a>
</div>

<script>
const navItems = document.querySelectorAll(".nav-item");

navItems.forEach(item => {
  item.addEventListener("click", function(){
    navItems.forEach(i => i.classList.remove("active"));
    this.classList.add("active");
  });
});
</script>

</body>
</html>