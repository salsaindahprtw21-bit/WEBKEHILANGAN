<?php include 'config.php'; ?>

<?php
$id = $_GET['id'];
$data = $koneksi->query("SELECT * FROM laporan WHERE id=$id");
$d = $data->fetch_assoc();

if(isset($_POST['update'])){
  $nama = $_POST['nama'];
  $kelas = $_POST['kelas'];
  $barang = $_POST['barang'];
  $deskripsi = $_POST['deskripsi'];

  $koneksi->query("UPDATE laporan SET 
  nama='$nama', kelas='$kelas', barang='$barang', deskripsi='$deskripsi'
  WHERE id=$id");

  header("Location: index.php");
}
?>

<link rel="stylesheet" href="style.css">

<form method="post" class="card">
<h3>Edit Laporan</h3>
<input type="text" name="nama" value="<?php echo $d['nama']; ?>">
<input type="text" name="kelas" value="<?php echo $d['kelas']; ?>">
<input type="text" name="barang" value="<?php echo $d['barang']; ?>">
<textarea name="deskripsi"><?php echo $d['deskripsi']; ?></textarea>
<button name="update" class="btn">Update</button>
</form>