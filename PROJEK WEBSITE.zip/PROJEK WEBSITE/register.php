<?php include 'config.php'; ?>

<?php
if(isset($_POST['register'])){
  $user = $_POST['username'];
  $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

  $koneksi->query("INSERT INTO users(username,password) VALUES('$user','$pass')");
  header("Location: login.php");
}
?>

<link rel="stylesheet" href="style.css">

<form method="post" class="card">
<h2>Daftar Akun Siswa</h2>
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button name="register" class="btn">Daftar</button>
<a href="login.php">Sudah punya akun? Login</a>
</form>