<?php
session_start();
$koneksi = new mysqli("localhost","root","","db_kehilangan");

if($koneksi->connect_error){
  die("Koneksi gagal: " . $koneksi->connect_error);
}
?>